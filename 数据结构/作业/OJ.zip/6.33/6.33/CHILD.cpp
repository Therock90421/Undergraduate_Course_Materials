#include<stdio.h>
#include<stdlib.h>

int judge(int left[],int right[], int u, int v,int &flag);
int flag ;
int main()
{
	int left[1000];
    int right[1000];
	char read[1000];
	
	int i,j,u,v,length;
	flag = 0;
	i = 0;
	j = 0;
	length = 0;
	while(scanf("%c",&read[i])!= EOF &&read[1000]!='\n' )
	{
		if(read[i]==','||read[i]==';')
		{
			if(read[i]==';')
				break;
			read[i] = 0;
			left[j++] = atoi(read);
			i = 0;
			continue;
		}
		else i++;
	}
	         read[i] = 0;
			 left[j++] = atoi(read);
			 length = j;
	i = 0;
	j = 0;
	while(scanf("%c",&read[i])!= EOF &&read[1000]!='\n' )
	{
		if(read[i]==','||read[i]==';')
		{
			if(read[i]==';')
				break;
			read[i] = 0;
			right[j++] = atoi(read);
			i = 0;
			continue;
		}
		else i++;
	}
	         read[i] = 0;
			 right[j++] = atoi(read);
    i = 0;
	j = 0;

	while(scanf("%c",&read[i])!= EOF &&read[1000]!='\n' )
	{
		if(read[i]==';')
		{		
			read[i] = 0;
			u = atoi(read);
			i = 0;
			break;
		}
		else i++;
	}
    i = 0;
	j = 0;

	while(scanf("%c",&read[i])!= EOF &&read[1000]!='\n' )
	{	
		 i++;
	}
		read[i] = 0;
		v = atoi(read);
		j = 0;
		i = 0;
	judge(left,right,u,v,flag);
		
    printf("%d",flag);
	return 1;
}

int judge( int left[],int right[],int u, int v,int &flag)
{
	int i = 0;
	
	if(left[v]==u)
	{
		flag = 1;
		return 0;
	}
	else if(right[v]==u)
	{   
		flag = 1;
		
		return 0;
	}
	else 
	{   
		if((i=left[v])!=0)
		
			judge(left,right,u,i,flag);
		
		if((i=right[v])!=0)
			
		judge(left,right,u,i,flag);
	}
	return 0;
}