#include<stdio.h>
#include<stdlib.h>

typedef struct Node{
	int tag;
	int position;
	int space;
}node;
typedef struct table{
	node v[30];
}TABLE;

int main()
{
	TABLE *g;
	node *p,*q;
	char s[30]={0};
	int u,v,h,i,j,k,flag;
	i = 0;
	j = 0;
	k = 0;
	u = 0;
	v = 0;
	h = 0;
    g = (TABLE *)malloc(sizeof(TABLE));
	for(i = 0;i < 30;i++)
		g->v[i].tag =2;        //2��ʾδ¼��
	i = 0;
	while(scanf("%c",&s[0])!=EOF&&s[0]!='\n')
	{
		u = atoi(s);
		g->v[i].tag = u;

		scanf("%c",&s[0]);
		j = 0;
		while(scanf("%c",&s[j])!=EOF&&s[j]!=' ')
		{
			j++;
		}
		s[j] = 0;
		v = atoi(s);
		for(k = 0;k<j;k++)
				s[k]=0;
		g->v[i].position = v;
		j = 0;
		while(scanf("%c",&s[j])!=EOF&&s[j]!='\n')
		{
			j++;
		}
		s[j] = 0;
		h = atoi(s);
		for(k = 0;k<j;k++)
				s[k]=0;
		g->v[i].space = h;
		
		i++;
	}

		j = 0;
		
		





	while(scanf("%c",&s[0])!=EOF&&s[0]!='\n')
	{
		u = atoi(s);
		if(u = 1)
		{
        p = (node *)malloc(sizeof(node));
		scanf("%c",&s[0]);
		j = 0;
		while(scanf("%c",&s[j])!=EOF&&s[j]!=' ')
		{
			j++;
		}
		s[j] = 0;
		v = atoi(s);
		for(k = 0;k<j;k++)
				s[k]=0;
		p->position = v;
		j = 0;
		while(scanf("%c",&s[j])!=EOF&&s[j]!='\n')
		{
			j++;
		}
		s[j] = 0;
		h = atoi(s);
		for(k = 0;k<j;k++)
				s[k]=0;
		p->space = h;
		
		flag = 0;
		for(i = 0;i < 30;i++)
		{
			if(g->v[i].tag==0)
				if(g->v[i].position == (p->position+p->space))
				{
					g->v[i].position = p->position;
					g->v[i].space = g->v[i].space+p->space;
					break;
				}
				else if(g->v[i].position+g->v[i].space  == p->position)
				{
					g->v[i].space = g->v[i].space+p->space;
					break;
				}
				else 
				{
					if(flag == 0&&p->position > g->v[i].position)
						continue;
					if(p->position < g->v[i].position)
						flag = 1;
				}
		        if(flag == 0)               //���ҵ�tag==2��û�ҵ����ʵ�λ��
				{
					g->v[i].tag = 0;
					g->v[i].position = p->position;
					g->v[i].space = p->space;
					break;
				}
				if(flag == 1)               //�ҵ����ʵ�λ��,��ʱiΪ��һ����p->position���λ�ã����ڰ�p���뵽i��λ��
				{
					j = i+1;
					while(g->v[j].tag !=2)   //jΪ���һ��Ԫ��
					{j++;}
					for(k = j;k>i;k--)
					{
						g->v[k].tag = 0;
					    g->v[k].position = g->v[k-1].position;
					    g->v[k].space = g->v[k-1].space;
					}
					    g->v[i].tag = 0;
					    g->v[i].position = p->position;
					    g->v[i].space = p->space;
						break;
				}
		}
	}
	}
	
	
	//�ϲ�
	i = 0;
	k = 0;
	while(g->v[k].tag!=2)
	{k++;}
	u = k;
	while(g->v[i].tag!=2)
	{j = 0;
		if(g->v[i].position+g->v[i].space == g->v[i+1].position)
		{
			g->v[i].space = g->v[i].space + g->v[i+1].space ;
			        while(g->v[j].tag !=2)   //jΪ���һ��Ԫ��
					{j++;}
					
					for(k = i+2;k<j;k++)
					{
						
					    g->v[k-1].position = g->v[k].position;
					    g->v[k-1].space = g->v[k].space;
					}
					    g->v[j-1].tag = 2;
					    g->v[j-1].position = 0;
					    g->v[j-1].space = 0;

		}
		u--;
		if(u == 0)
		{
			u = k;
		    i++;
		}
	}

		
		
	j = 0;
	while(g->v[j].tag!=2)
	{j++;}
	for(i = 0;i < j;i++)
		printf("%d %d %d\n",g->v[i].tag ,g->v[i].position,g->v[i].space);
	return 0;


}