#include<stdio.h>
#include<stdlib.h>
int number;
int show(int L[],int i,char s[]);
int change(int L[],int i,int K[]);

int main(){
	int L[1000]={0};
	int K[1000]={0};
	int i,j,length,u,v;
	char s[1000]={0};
	char c[1000]={0};
	i = 0;
	j = 1;

	while(scanf("%c",&s[i])!=EOF&&s[i]!='\n')
	{
		if(s[i]==',')
		{
			s[i]=0;
			while(L[j]== -1)
			{
				L[j] = 0;
				j++;
			}
			if(s[0]=='n')
			{   
				L[j]= 0;
				
				L[2*j] = -1;
				
				L[2*j+1] = -1;
				j++;
			}
			else  L[j++] = atoi(s);
		i = 0;
		continue;
		}
		i++;
	}
	s[i] = 0;
	if(L[j]== -1)
			{
				L[j] = 0;
				j++;
			}
	if(s[0]=='n')
		L[j++]= 0;
	else  L[j++] = atoi(s);
	length = j-1;
	i = 0;
	j = 1;
	
	

	number = 1;

	change(L,1,K);
	
	show(K,1,c);
	
	for(i = 1; i<=number-2;i++)
		if(c[i]!=',')
	        printf("%d",c[i]);
		else if(c[i]!=0)printf("%c",c[i]);
	return 0;
}
int show(int L[],int i,char s[])
{   
	s[number++] = L[i];
	s[number++] = ',';
	if(L[2*i]!=0)
		show(L,2*i,s);
	if(L[2*i+1]!=0)
		show(L,2*i+1,s);
	return 0;
}
int change(int L[],int i,int K[])
{   int j = 0;
	K[1] = L[1];
	for(i=2;i<9;i=i*2)
		for(j = 0;j<i;j++)
		{
			
			K[i+j] = L[2*i-1-j];
		}
return 0;
}
