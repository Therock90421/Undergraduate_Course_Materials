/*#include<stdio.h>

int comprior(char a, char b){
	int m, n;
	if(a == '*' || a == '/')
        m = 1;
    else m = 0;
    if(b == '*' || b == '/')
        n = 1;
    else n = 0;
    if(m > n)
        return 1;
	else return 0;}

int main(){
	int A,B;
	char A[1000],B[1000];
	char c;
	A=O;
	B=0;
	while(scanf("%c",&c)!=EOF){
		if(A)*/
#include<stdio.h>

int prior(char a, char b)
{
    int x, y;
    if(a == '*' || a == '/')
        x = 1;
    else x = 0;
    if(b == '*' || b == '/')
        y = 1;
    else y = 0;
    if(x > y)
        return 1;
    else return 0;
}

int main()
{
    int na, nb;
    char c, a[1000], b[1000];
    na = 0; nb = 0;
    while(scanf("%c", &c) != EOF)
    {
        if(('A' < c && c < 'Z') || ('a' < c && c < 'z'))
        {
            a[na] = c;
            na++;
            continue;
        }
        if(c == '(')
        {
            b[nb] = c;
            nb++;
            continue;
        }
        if(c == ')')
        {
            while(nb == 0 || b[nb - 1] != '(')
            {
                a[na] = b[nb - 1];
                na++; nb--;
            }
            if(nb != 0)
            {
                nb--;
                continue;
            }
            else continue;
        }
        while(1)
        {
            if(nb == 0 || b[nb - 1] == '(')
            {
                b[nb] = c;
                nb++;
                break;
            }
            if(prior(c, b[nb - 1]) == 1)
            {
                b[nb] = c;
                nb++;
                break;
            }
            a[na] = b[nb - 1];
            na++; nb--;        
        }
    }
    printf("%s", a);
    return 0;
}