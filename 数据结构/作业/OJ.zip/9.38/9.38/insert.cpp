#include<stdio.h>
#include<stdlib.h>
 


/*typedef struct BinNode{
    int data;
    struct BinNode *lchild;
    struct BinNode *rchild;
}BinNode,*BinTree;

void CreateBinTree(BinTree *tree)
{
    int ch;
    scanf("%d",&ch);
 
    if(ch == -1)
    {
        (*tree) = NULL;
    }
    else
    {
        *tree = (BinTree)malloc(sizeof(BinNode));
        (*tree)->data = ch;
        CreateBinTree(&((*tree)->lchild));
        CreateBinTree(&((*tree)->rchild));
    }
}
 
void Inorder(BinTree T)
{
    if(T)
    {
        Inorder(T->lchild);
        printf("%d ",T->data);
        Inorder(T->rchild);
    }
}
void Insert(BinTree *T,int key)
{
    if(!(*T))
    {
        (*T) = (BinTree)malloc(sizeof(BinNode));
        (*T)->data = key;
        (*T)->lchild = (*T)->rchild = NULL;
        return;
    }
    if(key == (*T)->data )
        return;
    if(key > (*T)->data )
        Insert( &((*T)->rchild), key );
    else
        Insert( &((*T)->lchild), key );
}
 
void InsertBST(BinTree T1,BinTree T2)
{
    if(T2)
    {
        InsertBST(T1,T2->lchild);
        Insert(&T1,T2->data);
        InsertBST(T1,T2->rchild);
    }
}



int main(){
	
    BinTree T1 = NULL;
    BinTree T2 = NULL;
    CreateBinTree(&T1);
    CreateBinTree(&T2);
    InsertBST(T1,T2);
    Inorder(T1);
    printf("\n");
    return 0;
}
*/int main()
{
	int L[1000] = {0};
	char s[10] = {0};
	int i,j,k,u;

	i = 0;
	j = 0;
	while(scanf("%c",&s[i])!=EOF&&s[i] !='\n' )
	{
		if(s[i] == ','||s[i] == ';')
		{
			if(s[0]!='n')
			{
			s[i] = 0;
			L[j] = atoi(s);
			j++;
			for(k = 0;k < i;k++)
				s[k] = 0;
			i = 0;
			continue;
			}
			else 
			{
				for(k = 0;k <= i;k++)
				s[k] = 0;
				i = 0;
				L[j] = -1;
				j++;
				continue;
			}
		}
		i++;
	}
	s[i] = 0;
			L[j] = atoi(s);
			j++;





	for(i = 0;i<j;i++)
		for(k = i+1;k<j;k++)
		{
			if(L[i]>L[k])
			{
				u = L[k];
				L[k] = L[i];
				L[i] = u;
			}
		}
		for(i = 0;i < j-1;i++)
			if(L[i]!=-1) printf("%d,",L[i]);
		printf("%d",L[j-1]);
		return 0;
}