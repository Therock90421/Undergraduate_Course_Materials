#include<stdio.h>
#include<stdlib.h>

int main(){
	int L[1000]={0};
	int K[1000]={0};
	int i,j,length,u,v;
	char s[1000]={0};
	char c[1000]={0};
	i = 0;
	j = 1;

	while(scanf("%c",&s[i])!=EOF&&s[i]!='\n')
	{
		if(s[i]==',')
		{
			s[i]=0;
			while(L[j]== -1)
			{
				L[j] = 0;
				j++;
			}
			if(s[0]=='n')
			{   
				L[j]= 0;
				
				L[2*j] = -1;
				
				L[2*j+1] = -1;
				j++;
			}
			else  L[j++] = atoi(s);
		i = 0;
		continue;
		}
		i++;
	}
	s[i] = 0;
	if(L[j]== -1)
			{
				L[j] = 0;
				j++;
			}
	if(s[0]=='n')
		L[j++]= 0;
	else  L[j++] = atoi(s);
	length = j-1;
	i = 0;
	j = 1;
	
	for(i = 1;i <= length;i++)
		if(L[i]==0)
		{
			printf("0");
			return 0;
		}

	printf("1");
	return 0;
}