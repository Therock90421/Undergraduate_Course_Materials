#include<stdio.h>
#include<stdlib.h>


typedef struct node{
	int data;
	struct node *next;
}Node;
typedef struct {
	node *h;
	node *t;
}Linklist;

int main()
{
	int i,j,k;
	int L[100] = {0};
	char s[10];
	int u,v;
	int number;
	Linklist *g;
	Node *p,*q,*r;
	g = (Linklist *)malloc(sizeof(Linklist));
	g->h = NULL;
	g->t = NULL;
	i = 0;
	number = 0;
	while(scanf("%c",&s[i])!=EOF&&s[i]!=';')
	{
		if(s[i] == ',')
		{
			s[i] = 0;
			
			u = atoi(s);
			
			for(j = 0;j < i;j++)
				s[j] = 0;
			i = 0;
			
			p = (Node *)malloc(sizeof(Node));
			p->data = u;
			p->next = NULL;

			if(g->h == NULL)
			{
				g->h = p;
				g->t = p;
				p->next = p;
			}
			else
			{
				g->t->next = p;
				p->next = g->h;
				q = p;
				g->t = q;
			}		
			
			continue;
		}

		
		i++;

	}
	        s[i] = 0;
			u = atoi(s);
			for(j = 0;j < i;j++)
				s[j] = 0;
			i = 0;
			
			p = (Node *)malloc(sizeof(Node));
			p->data = u;
			p->next = NULL;

			g->t->next = p;
				p->next = g->h;
				q = p;
				g->t = q;

     number = 0;
     while(scanf("%c",&s[i])!=EOF&&s[i]!='\n')
	 {
		 if(s[i]==',')
		 {
			s[i] = 0;
			
			L[number] = atoi(s);
			
			for(j = 0;j < i;j++)
				s[j] = 0;
			i = 0;
		    number++;
			continue;
		 }
		 i++;
		 
	 }
	 s[i] = 0;
			
			L[number] = atoi(s);
			
			for(j = 0;j < i;j++)
				s[j] = 0;
			i = 0;
		    number++;
        g->t = g->h;
	

				/*printf("%d ",g->h->data);
				p=g->h->next;
				while(p!=g->h)
				{
					printf("%d ",p->data );
					p = p->next;
				}*/
				
		for(i = 0; i<number; i++)
		{
			if(L[i]==g->t->data)
				printf("%d;",L[i]);
			else if(L[i] > g->t->data)
			{
				while(L[i]!=g->t->data)
				{
				printf("%d,",g->t->data);
				g->t = g->t->next;
				}
				if(i == number-1)
				{
					printf("%d",L[i]);
					return 0;
				}

				printf("%d;",L[i]);
			}
			else if(L[i] < g->t->data)
			{
				printf("%d,",g->t->data);
				g->t = g->h;
				while(L[i]!=g->t->data)
				{
					printf("%d,",g->t->data);
					g->t = g->t->next;
				}
				if(i == number-1)
				{
					printf("%d",L[i]);
					return 0;
				}
				printf("%d;",L[i]);

			}
		}
				
				return 0;



}