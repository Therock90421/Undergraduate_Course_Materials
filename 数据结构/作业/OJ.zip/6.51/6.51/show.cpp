#include<stdio.h>
#include<stdlib.h>


int main(){
    char L[100];
    char s[10];
    int i, j, length, u, v;
    i = 0;
    j = 1;

    while(scanf("%c", &s[i])!=EOF && s[i]!='\n'){
        if(s[i]==',' || s[i]==';'){
            if(s[i]==';')
                break;
            s[i] = 0;
            if(s[0]=='n')
                L[j++] = 0;
            else
                L[j++] = s[0];
            i = 0;
            continue;
        }
        i++;
    }
    s[i] = 0;
    if(s[0]=='n')
        L[j++] = 0;
    else
        L[j++] = s[0];
    length = j;
    i = 1;
    j = 0;
	
	if(L[i]=='*'||L[i]=='/')
		if(L[2*i]>='0'&&L[2*i+1]>='0'&&L[2*i]<='9'&&L[2*i+1]<='9')
			printf("%c%c%c",L[2*i],L[i],L[2*i+1]);
		else if(L[2*i]>='0'&&L[2*i]<='9')
			printf("%c%c(%c%c%c)",L[2*i],L[i],L[4*i+2],L[2*i+1],L[4*i+3]);
		else printf("(%c%c%c)%c%c",L[4*i],L[2*i],L[4*i+1],L[i],L[2*i+1]);

	else 
		if(L[2*i]>='0'&&L[2*i+1]>='0'&&L[2*i]<='9'&&L[2*i+1]<='9')
			printf("%c%c%c",L[2*i],L[i],L[2*i+1]);
		else if((L[2*i+1]=='+'&&L[i]=='-')||(L[2*i+1]=='-'&&L[i]=='-'))
			printf("%c%c(%c%c%c)",L[2*i],L[i],L[4*i+2],L[2*i+1],L[4*i+3]);
		else if(L[i]=='+'||L[i]=='-') printf("%c%c%c%c%c",L[2*i],L[i],L[4*i+2],L[2*i+1],L[4*i+3]);
		else printf("%c%c%c%c%c",L[4*i],L[2*i],L[4*i+1],L[i],L[2*i+1]);




	
	return 0;
}
