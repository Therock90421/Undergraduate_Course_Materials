#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int flag;
void print(char L[],int i, int j);
int main()
{
 
    
	int n;
	char L[1000]={0};
	
	int i,j,length,p;
	char s[1000]={0};
	char c[1000]={0};
	
	i = 0;
	j = 1;
	flag = 0;

	while(scanf("%c",&s[i])!=EOF&&s[i]!='\n')  //L
	{
		
		if(s[i]==',')
		{
			s[i]=0;
			while(L[j]== -1)
			{
				L[j] = 0;
				j++;
			}
			if(s[0]=='n')
			{   
				L[j]= 0;
				
				L[2*j] = -1;
				
				L[2*j+1] = -1;
				j++;
			}
			else  L[j++] = s[0];
		i = 0;
		continue;
		}
		i++;
	}
	s[i] = 0;
	if(L[j]== -1)
			{
				L[j] = 0;
				j++;
			}
	if(s[0]=='n')
		L[j++]= 0;
	else  L[j++] = s[0];
	length = j-1;
	i = 0;
	j = 1;
	flag = length;
	
	
    print(L,1,0);
    
    
    return 0;
}

void print(char L[],int i,int j)
{
	if(L[i]!=0)
	{
	for(int k = 0;k < j;k++)
		printf(" ");
	printf("%c\n",L[i]);
	}
	if(L[2*i]!=0)
	{
		print(L,2*i,j+1);
	}
	if(L[2*i+1]!=0)
	{
		print(L,2*i+1,j);
	}
}
