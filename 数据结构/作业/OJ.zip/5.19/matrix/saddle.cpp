#include<stdio.h>
#include <stdlib.h>


int main(){
	char a[10000] = {0};
	int  b[10000] = {0};
	char c       =  0;
	int  d       =  0;
	int  s[10000] = {0};
	int  rn      =  0;//����-1
	int  cn      =  0;//����
	int  cont    =  0;//������
	int  i,j,k,flag,p     =  0; 
	int  min[10000]     =  {0};
	int  cmin[10000]    =  {0};//��Сֵ���ڵ�����
	k = 0;
	while(scanf("%c",&c)!=EOF)
	{   
		if(c == ',')
		{   b[k]=atoi(a);
		    k++;
			for(i=0;i<=cont;i++)
				a[i]=0;
			cont = 0;
			cn++;

		continue;}
		else if(c == ';')
			{   
				b[k]=atoi(a);
		    k++;
			cont = 0;
			
				rn++;
		        cn = 0;}
		else if(c != '\n'){
			a[cont] = c;
			cont++;
			
		}
		else if(c == '\n'){
			b[k]=atoi(a);
		    k++;
			cont = 0;
			cn++;};
	}
	





	
	for( i = 0; i <= rn; i++)      //��ÿһ�е���СԪ
		{
			min[i] = b[i*cn];
			cmin[i]= 0;
			
		for( j= i*cn ; j <=(i+1)*cn-1 ; j++)
		     
			if(b[j] < min[i]){
				min[i] = b[j];
				cmin[i] = j-i*cn;}
				
		
	}
	
	//�ж���СԪ�ǲ�������
	k = 0;
	p = 0;
	
	
	
	for(i = 0; i <= rn; i++){
		
		for(p = 0; p < cn; p++)
			{
				flag = 1;
			if(min[i]==b[i*cn+p]){
				
				cmin[i] = p;
				
	       for(j = 0; j <= rn; j++)
		
			if(min[i] < b[j*cn+cmin[i]]){
				
				flag = 0;}
		
		if(flag)
			{
				s[k] = min[i];
		        k++;
		}
        
	}
	}
	}
	//����
	for (i = 0; i < k; i++)
{
    for (j = 0; j < k-1-i; j++)
{
    if (s[j] > s[j+1])
{
        d = s[j];
        s[j] = s[j+1];
        s[j+1] = d;
   }
   }
   }
	if(k>0){
	for(i=0;i<k-1;i++)
	printf("%d,",s[i]);
    printf("%d",s[k-1]);
	}
	else printf("null");
	
	
   return 0;
   }

	//ÿһ�в�һ��ֻ��һ����Сֵ