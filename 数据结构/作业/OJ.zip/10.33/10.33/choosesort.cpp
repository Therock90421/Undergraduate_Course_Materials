#include<stdio.h>
#include<stdlib.h>


typedef struct node{
	int data;
	struct node *next;
}Node;
typedef struct {
	Node *first;
	Node *last;
}LinkList;

int main()
{
	int i,j,u,v;
	LinkList *L,*G;
	Node *p,*q,*r;
	char s[1000] = {0};
	i = 0;
	L = (LinkList *)malloc(sizeof(LinkList));
	L->first = NULL;
	L->last = NULL;
	while(scanf("%c",&s[i])!=EOF&&s[i]!='\n')
	{
		if(s[i] == ',')
		{
			s[i] = 0;
			u = atoi(s);
			
			for(j = 0; j<i;j++)
				s[j] = 0;
			p = (Node *)malloc(sizeof(Node));
			p->data = u;
			i = 0;
			if(L->first == NULL)
			{
				L->first = p;
				L->last = p;
				p->next = NULL;
			}
			else
			{
				L->last->next = p;
				L->last = L->last->next;
				p->next = NULL;
			}
			continue;
		}
		i++;
	}
	        s[i] = 0;
			u = atoi(s);
			
			p = (Node *)malloc(sizeof(Node));
			p->data = u;
			L->last->next = p;
			L->last = L->last->next;
			p->next = NULL;
			
		

			G = (LinkList *)malloc(sizeof(LinkList));
			G->first = NULL;
			G->last = NULL;

			q = L->first;
			p = L->first->next;
			while(p!=NULL)
			{
				if(p->data < q->data)
					q = p;
				p = p->next;
			}
			G->first = q;
			G->last = q;
			if(q==L->first)
				{
					L->first = L->first->next;					
				}

			else
				{
					p = L->first;r = p->next;
		
				while(r!=q)
				{
					p = p->next;
					r = p->next;
				}
				
				p->next = r->next; 
				
				
			}
			






			while(L->first!=L->last)
			{
				
				
				q = L->first;
				p = L->first->next;
				while(p!=NULL)
				{
					if(p->data < q->data)
						q = p;
					p = p->next;
				}
				
				G->last->next = q;
				G->last = G->last->next;

                if(q==L->first)
				{
					L->first = L->first->next;
					continue;
				}
				

				p = L->first;r = p->next;
		
				while(r!=q)
				{
					p = p->next;
					r = p->next;
				}
				if(q==L->last)
				{
					L->last = p;
					p->next = NULL;
				}
				else 
				p->next = r->next; 
				
				
			}
			G->last->next  = L->first;
			G->last = G->last->next;

			p=G->first;
			while(p!=G->last)
			{
					printf("%d,",p->data);
					p = p->next;
			}
			printf("%d",p->data );

			
			return 0;

}