#include<stdio.h>
#include<stdlib.h>

int show(int L[],int node);
int flag;
int main(){
	int L[1000]={0};
	int K[1000]={0};
	int i,j,length,p;
	char s[1000]={0};
	char c[1000]={0};
	i = 0;
	j = 1;
	flag = 0;

	while(scanf("%c",&s[i])!=EOF&&s[i]!='\n')  //L
	{
		if(s[i]==';')
			break;
		if(s[i]==',')
		{
			s[i]=0;
			while(L[j]== -1)
			{
				L[j] = 0;
				j++;
			}
			if(s[0]=='n')
			{   
				L[j]= 0;
				
				L[2*j] = -1;
				
				L[2*j+1] = -1;
				j++;
			}
			else  L[j++] = atoi(s);
		i = 0;
		continue;
		}
		i++;
	}
	s[i] = 0;
	if(L[j]== -1)
			{
				L[j] = 0;
				j++;
			}
	if(s[0]=='n')
		L[j++]= 0;
	else  L[j++] = atoi(s);
	length = j-1;
	i = 0;
	j = 1;

	while(scanf("%c",&s[i])!=EOF&&s[i]!='\n')  //L
	{   
		if(s[i]==';')
			break;
		if(s[i]==',')
		{
			s[i]=0;
		    K[j++] = atoi(s);
			
		    i = 0;
		    continue;
		}
		i++;
	}
	s[i] = 0;
	
	if(s[0]=='n')
		K[j++]= 0;
	else  K[j++] = atoi(s);

	i = 1;
	j = 1;

    scanf("%c",&s[0]);
	p = atoi(s);

	for(i=1;L[i]!=p;i++);
	
	
    if(L[2*i]==0)
	{
		L[2*i]=K[1];
		L[4*i]=K[2];
		
	}
	else
	{
		L[4*i+1]=L[2*i];
		L[2*i]=K[1];
		L[4*i]=K[2];
		
	}
	
	i = 1;
	while(i<=16)
		if(L[i++]==-1)
			{
				L[i-1]=0;
				
		}
	i = 1;
	flag = 0;
	while(i<=16)
		if(L[i++]!=0)
			flag++;
	i = 0;
	show(L,1);
	



	return 0;
}
int show(int L[],int node)
{
    int c,d;
	c = 0;
	d = 0;


	if(L[node]!=0)
	{  
		if(L[2*node]!=0)
		{ 
			show(L,2*node);
			printf("0,%d,",L[2*node]);
			flag--;
		}
	    else if(L[2*node]==0)
		{       
			    c = node;
			    while(c%2==0)
					c = c/2;
				if(c == 1)
				{
				printf("1,0,");
				flag--;
				}
				else
				{
					c = c/2;
					printf("1,%d,",L[c]);
					flag--;
				}
		}

        if(L[2*node+1]!=0)
		{
			
			printf("0,%d;",L[2*node+1]);
			show(L,2*node+1);
		}
		else if(L[2*node+1]==0)
		{
			    d = node;
			    while(d%2==1)
					d = d/2;
				if(d==1)
				{
					if(flag!=0)
					printf("1,0;");
					if(flag == 0) {printf("1,0");flag = 1;}
				}
				else
				{   if(flag!=0)
				{
					d = d/2;
					printf("1,%d;",L[d]);
				}
				    if(flag == 0)
					{
				     d = d/2;
					 printf("1,%d",L[d]);
					 flag = 1;
				}
				}

		}
	}
	return 0;
}