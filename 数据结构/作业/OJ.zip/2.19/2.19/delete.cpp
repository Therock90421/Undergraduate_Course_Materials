#include<stdio.h>
#include<stdlib.h>

typedef struct LNode{
    int data;
	struct LNode *next;}LNode, *LinkList;

int main(){
	LinkList L,p,q;
	int i,k,mink,maxk,va[1000];
	k = 0;
	while(scanf("%d",&va[k])!= EOF)
		k++;                               //kΪԪ�ظ���
	k=k-1;                                 //va[0],...,va[k-1], ��ʱkΪ�������һ��Ԫ�صı��
	maxk = va[k];
	mink = va[k-1];
	L = (LinkList)malloc(sizeof(LNode));
	L->next = NULL;

	for(i=k-2;i>=0;i--){                      
		p = (LinkList)malloc(sizeof(LNode));
		p->data = va[i];
		p->next = L ->next;
		L->next = p;}                      //�������
	p = L;                                 //ͷ���
	do
    {
        if((p->next->data > mink )&& (p->next->data < maxk))
        {
            q = p->next;
            p->next = p->next->next;
            free(q);
        }
        else
            p = p->next;
    }
	while(p->next!=NULL);

	p = L->next;                          
	while(p->next!=NULL){
		printf("%d ",p->data);
		p = p->next;}
	printf("%d",p->data);
	return 0;
}
/*#include<stdio.h>
#include<stdlib.h>

typedef struct LNode
{
    int data;
    struct LNode *next;
}LNode, *LinkList;

int main()
{
    LinkList L, p, q;
    int i, n, mink, maxk, a[1000];
    n = 0;
    while(scanf("%d", &a[n]) != EOF)
        n++;
    n = n - 2;
    mink = a[n];
    maxk = a[n + 1];
    L = (LinkList)malloc(sizeof(LNode));
    L->next = NULL;
    for(i = n; i > 0; i--)
    {
        p = (LinkList)malloc(sizeof(LNode));
        p->data = a[i - 1];
        p->next = L->next;
        L->next = p;
    }

    p = L;
    do
    {
        if(p->next->data > mink && p->next->data < maxk)
        {
            q = p->next;
            p->next = p->next->next;
            free(q);
        }
        else
            p = p->next;
    }
    while(p->next != NULL);

    p = L->next;
    while(p->next != NULL)
    {
        printf("%d ", p->data);
        p = p->next;
    }
    printf("%d", p->data);
    return 0;
}*/