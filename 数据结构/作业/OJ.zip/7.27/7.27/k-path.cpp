#include<stdio.h>
#include<stdlib.h>

#define MAX_VERTEX_NUM 30
typedef int ElemType;
typedef struct node {
    int vindex; 	//�ڽӵ���ͷ��������е�λ��(�±�)
    struct node *next; //ָ����һ�������
} NodeLink; // ��������Ͷ���
typedef struct {
    // ͼ�Ķ�����������
    int vexnum; 
    struct {
        ElemType vertex;
        NodeLink *first;// ָ���һ�������
    }v[MAX_VERTEX_NUM];
}AGraph;
int flag;
void ListGraph(AGraph *g);
int visit[100]={0};
int DFS(AGraph *g,int u,int v);
int nowlength;
int main()
{
	int number;
	int length;
	
	char s[10]={0};
	AGraph *g;
	NodeLink *p,*q,*r;
	int u,v,i,h,k;
	i = 0;
	u = 0;
	v = 0;
	h = 0;
	k = 0;
	scanf("%c",&s[i]);
	number = atoi(s);
	scanf("%c",&s[0]);
	scanf("%c",&s[0]);
	length = atoi(s);
	scanf("%c",&s[0]);
	g = (AGraph *)malloc(sizeof(AGraph));
	g->vexnum = number;
	for(i = 1;i<=number;i++)
	{
		g->v[i].vertex = i;
		g->v[i].first = NULL;
	}
	
	scanf("%c",&s[0]);
	h = atoi(s);
	scanf("%c",&s[0]);
	scanf("%c",&s[0]);
	k = atoi(s);
	scanf("%c",&s[0]);
	do{
		scanf("%c",&s[0]);
		u = atoi(s);
		scanf("%c",&s[0]);
		scanf("%c",&s[0]);
		v = atoi(s);
		
		r = (NodeLink *)malloc(sizeof(NodeLink));
		r->vindex = v;
		if(g->v[u].first==NULL)
		{
			g->v[u].first=r;
			r->next = NULL;
			
		}
		else
		{
			p = g->v[u].first;
			q = p->next;
			while(q!=NULL&&r->vindex > q->vindex)
			{
				p = q;
				q = q->next;
			}
			p->next = r;
			r->next = q;
		}
	}while(scanf("%c",&s[i])!=EOF&&s[i]!='\n');

	flag = 0;
	nowlength = 0;



	DFS(g,h,k);
	if(flag==1&&nowlength==length)//
		printf("yes");
	else printf("no");
	return 0;
	


}


void ListGraph(AGraph *g) {
int i; NodeLink *p;
for(i=1;i<=g->vexnum;i++){
    printf("%d:%d--->",i,g->v[i].vertex);
    p=g->v[i].first;
    while(p) {
        printf("%3d",p->vindex);
        p=p->next;}
    printf("\n");
    }
}

int DFS(AGraph *g,int u,int v)
{
	NodeLink *p;
	visit[u]=1;
	if(g->v[u].first==NULL);
	else
	{
		nowlength++;
		p = g->v[u].first;
		while(p!=NULL)
		{
		if(p->vindex==v )
		{
			flag = 1;
			
			return 0;
			
		}
		else 
		{
			if(visit[p->vindex]==0)
			{
				
			DFS(g,p->vindex,v);
			if(flag==0)
			{
			nowlength--;
			}
			
			}
		}
		p = p->next;
		
		
		}
	}
}	


