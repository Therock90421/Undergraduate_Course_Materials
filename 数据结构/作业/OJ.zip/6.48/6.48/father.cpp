#include<stdio.h>
#include<stdlib.h>



int main(){
	int L[1000]={0};
	int K[1000]={0};
	int i,j,length,u,v;
	char s[1000]={0};
	char c[1000]={0};
	i = 0;
	j = 1;

	while(scanf("%c",&s[i])!=EOF&&s[i]!='\n')
	{   
		if(s[i]==';')
			break;
		if(s[i]==',')
		{
			s[i]=0;
			while(L[j]== -1)
			{
				L[j] = 0;
				j++;
			}
			if(s[0]=='n')
			{   
				L[j]= 0;
				
				L[2*j] = -1;
				
				L[2*j+1] = -1;
				j++;
			}
			else  L[j++] = atoi(s);
		i = 0;
		continue;
		}
		i++;
	}
	s[i] = 0;
	if(L[j]== -1)
			{
				L[j] = 0;
				j++;
			}
	if(s[0]=='n')
		L[j++]= 0;
	else  L[j++] = atoi(s);
	length = j-1;
	i = 0;
	j = 1;
	
	
	while(scanf("%c",&s[i])!=EOF&&s[i]!='\n')
	{
		if(s[i]==';')
		{
			s[i]=0;
			u = atoi(s);
			i = 0;
			continue;
		}
		i++;
	}
	        s[i]=0;
			v = atoi(s);
			i = 1;
			j = 1;
     while(L[i]!=u)
		 i++;           //L[i]=u
	 while(L[j]!=v)
		 j++;
	
	 if(i<j)
	  for(i;i>=1;i=i/2)
		 for(j;j>=1;j=j/2)
		 
			 if(i == j)
			 {
				 printf("%d",L[i]);
				 return 0;	 
			 }
	 if(i>=j)
		 for(j;j>=1;j=j/2)
		 for(i;i>=1;i=i/2)
		 
			 if(i == j)
			 {
				 printf("%d",L[i]);
				 return 0;	 
			 }

	printf("%d",L[1]);
	
	
	return 0;
}