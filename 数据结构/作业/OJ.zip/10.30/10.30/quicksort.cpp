#include<stdio.h>
#include<stdlib.h>


#define MAXSIZE 50
typedef int KeyType;
typedef struct {
	KeyType data;
}Elem;
typedef struct {
	Elem r[MAXSIZE+1];
	int length;
}SqList;
int partion(SqList *L,int low,int high);
void QuickSort(SqList *L);



int main()
{
	
	char s[100] = {0};
	int up[100] = {0};
	int down[100] = {0};
	int u,v,i,j,length;
	SqList *L;
	Elem *p;
	L = (SqList *)malloc(sizeof(SqList));

	i = 0;
	j = 0;
	length =0;
	while(scanf("%c",&s[i])!=EOF&&s[i]!='\n')
	{
		if(s[i] == ',')
		{
			s[i] = 0;
			u = atoi(s);
			for(j = 0;j<i;j++)
				s[j] = 0;
			L->r[length].data = u;
			i = 0;
			length++;
			continue;
		}
		i++;
		}
	        s[i] = 0;
			u = atoi(s);
			L->r[length].data = u;
			i = 0;
			L->length = length;

			//����
			QuickSort(L);

			for(i = 0;i<length;i++)
				printf("%d,",L->r[i].data);
			printf("%d",L->r[length].data);


	return 0;
}
 int partion(SqList *L,int low,int high){
        
	 int tmp=L->r[low].data;
            while(low<high){
                while(low<high&&L->r[high].data>=tmp){
                    --high;
                }
                if(low>=high){
                    break;
                }else{
                    L->r[low].data=L->r[high].data;
                }
                while(low<high&&L->r[low].data<=tmp){
                    ++low;
                }
                if(low>=high){
                    break;
                }else{
                    L->r[high].data=L->r[low].data;
                }
            
        }
            L->r[low].data=tmp;
            return low;
        
    }

 void QuickSort(SqList *L){
	    int *stack=new int[L->length+1];
        int top=0;
        int low=0;
        int hign=L->length;
        int par=partion(L,low,hign);
        //��ջ
        if(par>low+1){
            stack[top++]=low;
            stack[top++]=par-1;
        }
        if(par<hign-1){
            stack[top++]=par+1;
            stack[top++]=hign;
        }
        //��ջ
        while(top>0){
            hign=stack[--top];
            low=stack[--top];
            par=partion(L,low,hign);
            if(par>low+1){
                stack[top++]=low;
                stack[top++]=par-1;
            }
            if(par<hign-1){
                stack[top++]=par+1;
                stack[top++]=hign;
                
            }
            
        }
    }