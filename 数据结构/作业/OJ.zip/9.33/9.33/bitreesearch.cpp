#include<stdio.h>
#include<stdlib.h>
int number;
int k;
int show(int L[],int i,char s[]);
int visit(int L[],int i,int j,int K[]);
int main(){
	int L[1000]={0};
	int K[1000]={0};
	int i,j,length,u,v;
	char s[1000]={0};
	char c[1000]={0};
	i = 0;
	j = 1;
	k = 0;
	while(scanf("%c",&s[i])!=EOF&&s[i]!=';')
	{
		if(s[i]==',')
		{
			s[i]=0;
			while(L[j]== -1)
			{
				L[j] = 0;
				L[2*j] = -1;
				L[2*j+1] = -1;
				j++;
			}
			if(s[0]=='n')
			{   
				L[j]= 0;
				
				L[2*j] = -1;
				
				L[2*j+1] = -1;
				j++;
			}
			else  L[j++] = atoi(s);
		i = 0;
		continue;
		}
		i++;
	}
	s[i] = 0;
	if(L[j]== -1)
			{
				L[j] = 0;
				L[2*j] = -1;
				L[2*j+1] = -1;
				j++;
			}
	if(s[0]=='n')
		L[j++]= 0;
	else  L[j++] = atoi(s);
	length = j-1;
	i = 0;
	j = 1;

	scanf("%c",&s[0]);
	s[1] = 0;
	u = atoi(s);
	i = 1;
	
	
	visit(L,1,u,K);
	j = 0;
	while(K[j]>0)
	{
		j++;
	}

    for(i = j-1;i>0;i--)
		printf("%d,",K[i]);
	printf("%d",K[0]);
	
	return 0;
}
int show(int L[],int i,char s[])
{   
	s[number++] = L[i];
	s[number++] = ',';
	if(L[2*i]!=0)
		show(L,2*i,s);
	if(L[2*i+1]!=0)
		show(L,2*i+1,s);
	return 0;
}
int visit(int L[],int i,int j,int K[])
{
	if(L[i]==0)  return 0;
	else 
	{
		visit(L,2*i,j,K);
		if(L[i]>=j) K[k++] = L[i];
		visit(L,2*i+1,j,K);
	}
	return 0;
}