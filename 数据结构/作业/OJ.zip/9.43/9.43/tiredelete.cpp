#include<stdio.h>
#include<string.h>
//using namespace std;
	int L[26*26*26*26*26];     //��һά����ģ��5��trie��
	int flag=0;
	
void show(int now)
{
	for(int i=now*26;i<=now*26+25;i++)
	{
		if(L[i]>0)
		{
			if(flag)
				printf(",");
			else
				flag=1;
			if(L[i] >= 10) printf("%d",L[i]-10);
			else printf("%d",L[i]);
			if(i<=26*26*26*26*26) show(i);
		}
		
		
	}
}

int main()
{

	int maxlength; 
	int length=0;
	int sum=0;
	memset(L,0,sizeof(L));
	char ch;
	scanf("%d",&maxlength);

	while((ch=getchar())!=EOF&&ch!='\n')
	{

		length++;
		if(ch==';' || ch==',')
		{
			length=0;
			sum=0;
		}
		if(length>maxlength)
			continue;
		
		if(('a'<=ch && ch<='z') || ('A'<=ch && ch<='Z'))
		{
			
			
			sum=sum*26+(ch-96);
			L[sum]++;

		}		
	}

	while(sum > 0)
	{
		L[sum] = L[sum]+8;
		sum = sum / 26;
	}


	show(0);	
 } 