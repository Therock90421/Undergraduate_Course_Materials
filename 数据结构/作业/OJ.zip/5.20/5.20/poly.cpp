#include<stdio.h>
#include<stdlib.h>
extern int num[1000] = {0};
extern int position[1000] = {0};
void print(int i,int j,int *s);
int main(){
	int a,b,k,i,flag,m,lenth,number;
	int *s;  //����
	char put;
	char c[1000] = {0};
	
	a = 0;
	b = 0;
	lenth = 0;
	k = 0;
	m = 0;
	flag = 0;
	number = 0;
	while(scanf("%c",&put)!=EOF){
		if(put == ';'&&flag<2){
	    if(flag == 0)
			{
		     a = atoi(c);                  //a�Ǳ�Ԫ����
		     for(i = 0; i < k;i++)
			     c[i] = 0;
		     k = 0;
			 flag++;
			 		
             continue;
		    }
		else
		{
		     b = atoi(c);                 //b��ÿһά�ĳ���
		     for(i = 0; i < k;i++)
			     c[i] = 0;
		     k = 0;
			 flag++;

			 lenth = b;
		for(i = 1; i < a;i++)
			     lenth = lenth*b;	  		

        s = (int *)malloc(sizeof(int)*(lenth));
		
		for(i = 0; i < lenth;i++)
			     *(s+i) = 0;
		
		continue;
		}
		}

		if((put == ';'&&flag==2)||(put ==','))
		{  
			number=atoi(c);
			s[m]=number;
			m++;
			
			
			
			for(i = 0; i < k;i++)
			     c[i] = 0;
		     k = 0;
			 continue;
		}
		if(put == '\n')
		{
			*(s+m)=atoi(c);
			m++;
			for(i = 0; i < k;i++)
			     c[i] = 0;
		     k = 0;
			 continue;
		}
		
		if(put == '['||put == ']')
			continue;

		c[k] = put;
		k++;
		
	}//��ɶ���

	for(i=0;i<a;i++)
		num[i] = b;

	print(0,b,s);
	return 0;
}

void print(int i,int j,int *s){
	int list,k,flag = 0;
	int mi[1000] = {0};
	if(num[i])
		for(position[i]=j-1;position[i]>=0;position[i]--)
			print(i+1,num[i+1],s);
	else {
		mi[0]=1;
		mi[1]=num[i-1];                             //mi[k] = b^(k)
		for(k = 2;k<i+1;k++)
			mi[k] = mi[k-1]*num[i-1];
		list = 0;
		for(k = 0; k<i;k++)
			list = list + position[k]*mi[i-k-1];
		
		if(*(s+list)!=0)
		{   flag = 0;
		    for(k = 0;k <i; k++)
		        {
				if(position[k]>0)
					flag = 1;}
		    if(*(s+list)==1&&flag ==0)
				printf("1");
			else
			{
				if(*(s+list)!=1)
					printf("%d",*(s+list));
				for(k = 0;k < i;k++)
				{   if(position[k]==1)
				        printf("x%d",k+1);
					else if(position[k])
				 	printf("x%dE%d",k+1,position[k]);
				}
				if(flag == 1)
					printf("+");

			}
		}

	}
}