#include<stdio.h>

int main(){
	char a[1000]={0};
	int n=0;
	int flag=1;
	int i;
	char c;
	while(scanf("%c",&c)!=EOF){
		if(c == '\n')
		continue;
		if(c == '@'){
	         n--;
			 for(i = 0; i <= n; i++)
            {
                if(a[i] != a[n - i])
                    flag = 0;
            }
			 printf("%d",flag);}
		a[n]=c;
		n++;}
	return 0;

}