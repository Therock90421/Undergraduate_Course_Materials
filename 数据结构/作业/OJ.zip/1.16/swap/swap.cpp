#include <stdio.h>
void main()
{
    int x,y,z;
    while(scanf("%d%d%d", &x,&y,&z) != EOF)
    if(x<=y)
		if(y<=z) printf("%d %d %d",z,y,x);
		else if(x<=z) printf("%d %d %d",y,z,x);
		     else printf("%d %d %d",y,x,z);
	else if(x<=z) printf("%d %d %d",z,x,y);
		else if(z<=y) printf("%d %d %d",x,y,z);
		     else printf("%d %d %d",x,z,y);
		
    return ;
}
