#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int L[100][100]={0};

int insertv(int i);
int inserta(int i, int j);
int deletev(int i);
int deletea(int i, int j);
int main()
{
	
	int K[1000] = {0};
	int M[1000] = {0};
	
	char s[1000]={0};
	char c[1000]={0};
	int i,j,k;
	int u,v;
	int number;
	int flag;
	 
	number = 0;
	
	i = 0;
	j = 0;
	u = 0;
	v = 0;
   
	while(scanf("%c",&s[i])!=EOF)
	{
		if(s[i]=='\n'||s[i]==' ')
			break;
		i++;
	}
	
	s[i] = 0;
	number = atoi(s);
	
	
	i = 0;
	while(scanf("%c",&s[i])!=EOF&&s[i]!='\n')
	{
		if(s[i]=='-')
		{
			s[i] = 0;
			u = atoi(s);
			L[u][u]=1;
			i = 0;
			continue;
		}
		if(s[i]==',')
		{
			s[i]=0;
			v = atoi(s);
			i = 0;
			L[u][v] = 1;
			
			L[v][v]=1;
			
			K[u]++;
			M[v]++;
			continue;
		}
		i++;
	}
	        s[i]=0;
			v = atoi(s);
			i = 0;
			L[u][v] = 1;
			
			L[v][v]=1;

			K[u]++;
			M[v]++;


			
			
			while(scanf("%c",&s[i])!=EOF)
			{
				if(s[i]=='\n')
				{
					if(s[0]=='I'&&s[1]=='V')
					{
						c[0]=s[3];
						u=atoi(c);
						insertv(u);
						i = 0;
						number++;
						
						continue;
					}
					if(s[0]=='D'&&s[1]=='V')
					{
						c[0]=s[3];
						u=atoi(c);
						deletev(u);
						i = 0;
						number--;
						continue;
					}
					if(s[0]=='I'&&s[1]=='A')
					{
						c[0]=s[3];
						u=atoi(c);
						c[0]=s[5];
						v=atoi(c);
						inserta(u,v);
						i = 0;
						
						continue;
					}
					if(s[0]=='D'&&s[1]=='A')
					{
						c[0]=s[3];
						u=atoi(c);
						c[0]=s[5];
						v=atoi(c);
						deletea(u,v);
						i = 0;
						
						continue;
					}
				}
				i++;
			}
			flag = number;
		for(i = 0;i<=10;i++)
			{
				flag = number;
			    for(j = 0;j<=10;j++)
				{
					if(L[i][i]==1&&L[j][j]==1)
					{ 
						if(j==i)
						{
							if(flag>1)
							{
							printf("0,");
							flag--;}
							else  printf("0\n");
						}
						else 
							{
								if(flag>1)
								{
								printf("%d,",L[i][j]);
								flag--;
								}
								else printf("%d\n",L[i][j]);
						}
					}
					
				}
			}






	return 0;
}

int insertv(int i)
{
	L[i][i]=1;
	return 0;

}

int inserta(int i, int j)
{
	L[i][j]=1;
	return 0;
}

int deletev(int i)
{
    L[i][i]=0;
	return 0;
}

int deletea(int i, int j)
{
	L[i][j]=0;
	return 0;
}