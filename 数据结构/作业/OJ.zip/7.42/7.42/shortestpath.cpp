#include<stdio.h>
#include<stdlib.h>

#define MAX_VERTEX_NUM 30
typedef int ElemType;
typedef struct node {
    int vindex; 	//�ڽӵ���ͷ��������е�λ��(�±�)
    struct node *next; //ָ����һ�������
} NodeLink; // ��������Ͷ���
typedef struct {
    // ͼ�Ķ�����������
    int vexnum; 
    struct {
        ElemType vertex;
        NodeLink *first;// ָ���һ�������
    }v[MAX_VERTEX_NUM];
}AGraph;
int flag;
void ListGraph(AGraph *g);
int visit[100]={0};int distance[10]={0};
int DFS(AGraph *g,int u,int v);
int nowlength;
int number;
int getmin();
int correct(int link[10][10],int j);
int main()
{
	
	int base;
	int degree[10]={0};
	int link[10][10]={0};
	
	char s[10]={0};
	AGraph *g;
	NodeLink *p,*q,*r;
	int u,v,i,h,k,j;
	base = 0;
	i = 0;
	u = 0;
	v = 0;
	h = 0;
	k = 0;
	j = 0;
	scanf("%c",&s[0]);
	number = atoi(s);
	scanf("%c",&s[0]);
	scanf("%c",&s[0]);
	base = atoi(s);
	scanf("%c",&s[0]);
	

	
	g = (AGraph *)malloc(sizeof(AGraph));
	g->vexnum = number;
	for(i = 1;i<=number;i++)
	{
		g->v[i].vertex = i;
		g->v[i].first = NULL;
	}
	

	while(scanf("%c",&s[0])!=EOF){
		
		u = atoi(s);
		scanf("%c",&s[0]);
		scanf("%c",&s[0]);
		v = atoi(s);
		scanf("%c",&s[0]);
		
		i = 0;
		
		while(scanf("%c",&s[i])!=EOF&&s[i]!='\n'){i++;}
		
			s[i] = 0;
            h = atoi(s);
			for(j = 0;j<i;j++)
				s[j]=0;
			
			i = 0;
		
		
		
		

		
		
		link[u][v] = h;
		
		r = (NodeLink *)malloc(sizeof(NodeLink));
		r->vindex = v;
		if(g->v[u].first==NULL)
		{
			g->v[u].first=r;
			r->next = NULL;
			
		}
		else
		{
			p = g->v[u].first;
			
			q = p->next;
			while(q!=NULL&&r->vindex > q->vindex)
			{
				p = q;
				q = q->next;
			}
			p->next = r;
			r->next = q;
			
		}
	}

	flag = 0;
	
	
	visit[base] = 1;
	for(i = 1; i <= number; i++)
		if(i!=base) distance[i] = link[base][i];  //��ʼ��
	i = 0;
	i = getmin();
	

	do{
		correct(link,i);
	

		i = getmin();
	}while(i);
	
    for(i = 1;i < number; i++)
	{
		if(i!=base)
			printf("%d,",distance[i]);
	}
	printf("%d",distance[number]);

/*
	for(i = 1;i<=number;i++)
	for(j = 1;j<=number;j++)
	if(i!=j){
	nowlength = 0;
	DFS(g,i,j);
	if(degree[i]<nowlength)
		degree[i] = nowlength;
	for(k = 1;k<=number;k++)
		visit[k]=0;
	}
	for(i = 1;i < number; i++)
		printf("%d,",degree[i]);
	printf("%d",degree[number]);
	/*nowlength = 0;
	DFS(g,5,4);
	printf("%d",nowlength);*/
	return 0;
	


}
int getmin()
{
	int i = 1;
	int j = 1;
	int dis = 1000;
	for(i = 1;i <= number;i++)
	{
		if(visit[i]==0)
		{
			if(distance[i]!=0)
				if(dis > distance[i])
				{   
					dis = distance[i];
					j = i;
				}
		}
		
	}
        if(dis == 1000)  return 0;
		visit[j]=1;       //����S
		
		return j;
}
int correct(int link[10][10],int j)
{
	int i = 1;
	for(i = 1;i <= number; i++)
		if(visit[i] == 0)
		{
			if(link[j][i])
				
			if(distance[i]>(distance[j]+link[j][i])||distance[i]==0)
				distance[i] = distance[j]+link[j][i];
		}
		return 0;
}

void ListGraph(AGraph *g) {
int i; NodeLink *p;
for(i=1;i<=g->vexnum;i++){
    printf("%d:%d--->",i,g->v[i].vertex);
    p=g->v[i].first;
    while(p) {
        printf("%3d",p->vindex);
        p=p->next;}
    printf("\n");
    }
}

int DFS(AGraph *g,int u,int v)
{
	NodeLink *p;
	visit[u]=1;
	
	if(g->v[u].first==NULL){}
	else
	{   
		nowlength++;
		p = g->v[u].first;
		
		while(p!=NULL)
		{
		if(p->vindex==v )
		{
			
			flag = 1;
			
			return 0;
			
		}
		else 
		{
			
			if(visit[p->vindex]==0)
			{
				
			DFS(g,p->vindex,v);
			if(flag==0)
			{
			nowlength--;
			}
			else return 0;
			}
		}
		p = p->next;
		
		
		}
	}
	return 0;
}	


