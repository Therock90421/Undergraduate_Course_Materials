/*#include<stdio.h>
#include<stdlib.h>

typedef struct LNode{
    char data;
	struct LNode *next;}LNode, *LinkList;

int main(){
	LinkList L,p,reverse;
	int i,k;
	char va[1000];
	k = 0;
	while(scanf("%d",&va[k])!= EOF)
		if(va[k] != ',')
            k++;                              //kΪԪ�ظ���
	k=k-1;                                 //va[0],...,va[k-1], ��ʱkΪ�������һ��Ԫ�صı��
	
	L = (LinkList)malloc(sizeof(LNode));
	L->next = NULL;

	for(i=k;i>=0;i--){                      
		p = (LinkList)malloc(sizeof(LNode));
		p->data = va[i];
		p->next = L ->next;
		L->next = p;}                      //�������
	    p = L->next;
        L->next = NULL;               //ͷ���
	while(p!=NULL){
		reverse = p;
		
		printf("%c,",p->data);
		p = p->next;}
	printf("Q")     ;
	printf("%c",p->data);
	return 0;
}*/
#include<stdio.h>
#include<stdlib.h>

typedef struct LNode
{
    char data;
    struct LNode *next;
}LNode, *LinkList;

int main()
{
    LinkList L, p, reverse;
    int i, n;
    char a[1000];
    n = 0;
    while(scanf("%c", &a[n]) != EOF)
        if(a[n] != ',')
            n++;
    L = (LinkList)malloc(sizeof(LNode));
    L->next = NULL;
    for(i = n; i > 0; i--)
    {
        p = (LinkList)malloc(sizeof(LNode));
        p->data = a[i - 1];
        p->next = L->next;
        L->next = p;
    }

    p = L->next;
    L->next = NULL;
    while(p != NULL)
    {
        reverse = p;
        p = p->next;
        reverse->next = L->next;
        L->next = reverse;
    }

    p = L->next;
	p=p->next;
    while(p->next!= NULL)
    {
        printf("%c,", p->data);
        p = p->next;
    }
    printf("%c", p->data);
    return 0;
}
