# include <stdio.h>
# define arrsize 300
# define MAXINT 65535
 
int main()
{
    int i,n,a[arrsize];
	
    scanf("%d", &n);
    if(n>arrsize)
		return -1;
	if(n<1)
		return -1;
    a[0]=1;
    for(i=1;i<n;i++)
    {
        a[i]=i*a[i-1]*2;
        if(a[i]>MAXINT){
			printf("%d",a[6]);
			return -1;}
    }
    printf("%d",a[n-1]);
    return 0;
}