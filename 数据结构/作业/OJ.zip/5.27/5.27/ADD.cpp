#include<stdio.h>
#include<stdlib.h>


int main(){
	int a,b,k,i,flag,m,lenth,number,adder;
	int *s,*r;  //����
	int element[1000]={0};
	char put;
	char c[1000] = {0};
	
	a = 0;
	b = 0;
	lenth = 0;
	k = 0;
	m = 0;
	flag = 0;
	adder = 0;
	number = 0;
	while(scanf("%c",&put)!=EOF){
		if((put == ';'||put == ':')&&flag<2){
	    if(flag == 0)
			{
		     a = atoi(c);                  //a�Ǳ�Ԫ����
		     for(i = 0; i < k;i++)
			     c[i] = 0;
		     k = 0;
			 flag++;
			 		
             continue;
		    }
		else
		{
		     b = atoi(c);                 //b��ÿһά�ĳ���
		     for(i = 0; i < k;i++)
			     c[i] = 0;
		     k = 0;
			 flag++;

			 lenth = a*b;
			  		

        s = (int *)malloc(sizeof(int)*(lenth));
		r = (int *)malloc(sizeof(int)*(lenth));

		for(i = 0; i < lenth;i++)
		{
			     *(s+i) = 0;
				 *(r+i) = 0;
		}
		continue;
		}
		}

		if((((put == ';'||put == ':')&&flag==2)||(put ==','))&& adder == 0)
		{  
			number=atoi(c);			
			s[m]=number;			
			m++;
			
			
			
			for(i = 0; i < k;i++)
			     c[i] = 0;
		     k = 0;
			 continue;
		}
		if(((put == ';'&&flag==2)||(put ==','))&& adder == 1)
		{  
			number=atoi(c);
			r[m]=number;			
			m++;
			
			
			
			for(i = 0; i < k;i++)
			     c[i] = 0;
		     k = 0;
			 continue;
		}


		if(put == '\n')
		{
			*(r+m)=atoi(c);
			m++;
			for(i = 0; i < k;i++)
			     c[i] = 0;
		     k = 0;
			 continue;
		}
		
		if(put == '['||put == ']')
			continue;
		if(put == '+')
		{
			number=atoi(c);
			s[m]=number;			
			for(i = 0; i < k;i++)
			     c[i] = 0;
		     k = 0;

			m = 0;
			adder = 1;
			continue;
		}
		c[k] = put;
		k++;
		
	}//��ɶ���
	i = 0;
    while(i!=lenth)
	{
		s[i] = s[i] + r[i];
		i++;
	}
	printf("[");
	for(i = 0; i < lenth; i++)
	{
		if( i%b == 0)
			printf("[%d,",s[i]);
		else if(i%b == b-1&&i!=lenth-1)
			printf("%d];",s[i]);
		else if(i%b == b-1)
			printf("%d]",s[i]);
		else printf("%d,",s[i]);
	}
	printf("]");
	return 0;

	


}