#include<stdio.h>

int main(){
	int a,n,temp,va[1000],i;
	n=0;
	while(scanf("%d",&va[n])!=EOF)
		n++;
	a=n-1;
	while(va[a-1]>va[a]){
		temp=va[a];
		va[a]=va[a-1];
		va[a-1]=temp;
		a--;}
	for(i=0;i<n-1;i++)
		printf("%d ",va[i]);
	printf("%d",va[i]);
	return 0;}





