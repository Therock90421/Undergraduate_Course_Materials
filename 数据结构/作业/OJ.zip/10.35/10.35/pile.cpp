#include<stdio.h>
#include<stdlib.h>

int L[1000] = {0};//��������
int swap(int h,int length);
int sp(int h, int length);
int main()
{
	int length,i,j,u,v,flag;
	
	char s[100]={0};

	i = 0;
	length = 0;
	while(scanf("%c",&s[i])!=EOF&&s[i]!='\n')
	{
		if(s[i] == ',')
		{
			s[i] = 0;
			u = atoi(s);
			for(j = 0; j< i;j++)
			    s[j] = 0;
			i = 0;
			L[length] = u;
			length++;
			continue;
		}
		i++;
	}
	        s[i] = 0;
			u = atoi(s);
			
			i = 0;
			L[length] = u;
			length++;

			flag = 1;
			while(length>0)
			{
				

				v = length-2;
				v = v/3;   //���һ�����ӽ��
				swap(v,length);

				v = L[0];
				L[0] = L[length-1];
				L[length-1] = v;
				length--;

				i = 0;

			




				sp(0,length);
			}
			i = 0;
			printf("%d",L[0]);
			i = 1;
			while(L[i]>0)
			{
				printf(",%d",L[i]);
				i++;
			}
	
return 0;
}

int swap(int h,int length)
{
	
	int i,j,k,u;
	if(h >= 0)
	{
	for(i = 3*h+1;i<=3*h+3;i++)
	{
		if(L[i]!=0&&L[i]>L[h]&&i<length)
		{
			u = L[h];
			L[h] = L[i];
			L[i] = u;
			
			
			
			
			
			
			
			swap(i,length);
		}

	}
	swap(h-1,length);
	}
	
	return 0;
}
int sp(int h,int length)
{
	int i,j,k,u;
	
	if(h<=(length-2)/3)
	{
		for(i = 3*h+1;i<=3*h+3;i++)
	    {
		if(L[i]!=0&&L[i]>L[h]&&i<length-1)
		{
			u = L[h];
			L[h] = L[i];
			L[i] = u;

			


	}
	}
		sp(h+1,length);
}
	return 0;
}