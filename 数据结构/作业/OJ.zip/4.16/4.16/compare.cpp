#include<stdio.h>

int main(){
	char a[1000] = {0};
	char b[1000] = {0};
	int i,na,nb,count,flag;
	char c;
	na = 0;  nb = 0; count = 0;
	while(scanf("%c",&c)!= EOF)
	{
		if(c == ' ')
		{	
			count = 1;
		    continue;
		}
		if(c == '\n')
		{
			i = 0;
			flag = 0;
			while(i < na && i < nb)
			{
				if(a[i] < b[i])
				{
					flag = -1;
					break;
				}
				if(a[i] > b[i])
				{
					flag = 1;
					break;
				}
				i++;
			}
			if(flag == 0)
			{
				if(na < nb)
					flag = -1;
				if(na > nb)
					flag = 1;
			}
			printf("%d",flag);

			na = 0;
			nb = 0;
			count = 0;
			continue;
		}
		if(count == 0)
		{
			a[na] = c;
			na++;
			continue;
		}
		if(count == 1)
		{
			b[nb] = c;
			nb++;
			continue;
		}

	}
	return 0;
}