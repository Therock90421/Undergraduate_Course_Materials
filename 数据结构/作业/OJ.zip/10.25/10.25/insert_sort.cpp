#include<stdio.h>
#include<stdlib.h>

#define MAXSIZE 50
typedef int KeyType;
typedef struct {
	KeyType data;
}Elem;
typedef struct {
	Elem r[MAXSIZE+1];
	int length;
}SqList;


void BInsertSort(SqList *L)
{
	for(int i = 2; i <=L->length; i++)
	{
		L->r[0] = L->r[i];
		int low = 1;
		int high = i-1;
		while(low <= high)
		{
			int m = (low + high)/2;
			if(L->r[0].data<L->r[m].data) high = m-1;
			else low = m+1;
		}
		for(int j = i-1;j >= high+1;j--) L->r[j+1] = L->r[j];
		L->r[high + 1] = L->r[0];



	}
}

int main()
{
	
	char s[100] = {0};
	int u,v,i,j,length;
	SqList *L;
	Elem *p;
	L = (SqList *)malloc(sizeof(SqList));

	i = 0;
	j = 0;
	length =1;
	while(scanf("%c",&s[i])!=EOF&&s[i]!='\n')
	{
		if(s[i] == ',')
		{
			s[i] = 0;
			u = atoi(s);
			for(j = 0;j<i;j++)
				s[j] = 0;
			L->r[length].data = u;
			i = 0;
			length++;
			continue;
		}
		i++;
		}
	        s[i] = 0;
			u = atoi(s);
			L->r[length].data = u;
			i = 0;
			L->length = length;

			BInsertSort(L);

			for(i = 1;i<length;i++)
				printf("%d,",L->r[i].data);
			printf("%d",L->r[length].data);


	return 0;
}