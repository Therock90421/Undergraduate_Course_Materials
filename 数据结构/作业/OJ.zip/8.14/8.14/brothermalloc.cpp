#include<stdio.h>
#include<stdlib.h>

typedef struct Node{
	int exp;
	int position;
}node;
typedef struct {
	node v[30];
}table;
table *g;
int flag;
int mul(int i, int j);
int insert(int u, int v);
void exchange(int j);
int main()
{	
	char s[30]={0};
	
	int u,v,h,i,j,k,number;
	i = 0;
	j = 0;
	k = 0;
	u = 0;
	v = 0;
	h = 0;
	g = (table *)malloc(sizeof(table));
	for(i = 0;i < 30;i++)
		g->v[i].exp =-1;        //-1��ʾ��
	i = 0;
	j = 0;
	while(scanf("%c",&s[0])!=EOF&&s[0]!='\n')
	{
		u = atoi(s);
		scanf("%c",&s[0]);
		while(scanf("%c",&s[i])!=EOF&&s[i]!='\n')
		{
			if(s[i] == ' ')
			{
				s[i] = 0;
				v = atoi(s);
				g->v[j].exp = u;
				g->v[j].position = v;
				
				j++;
				for(k = 0; k < i; k++)
					s[k]=0;
				i = 0;
				continue;
			}
			i++; 
		}
		        s[i] = 0;
				v = atoi(s);
				g->v[j].exp = u;
				g->v[j].position = v;
				j++;
				for(k = 0; k < i; k++)
					s[k]=0;
				i = 0;
		}//��һ���ֶ�ȡ���          //j��ʱΪԪ������+1
	i = 0;
	number = j;
	
	while(scanf("%c",&s[0])!=EOF&&s[0]!='\n')
	{
		u = atoi(s);
		scanf("%c",&s[0]);
		while(scanf("%c",&s[i])!=EOF&&s[i]!='\n')
		{
			if(s[i] == ' ')
			{
				s[i] = 0;
				v = atoi(s);
				
				
				insert(u,v);
				
				for(k = 0; k < i; k++)
					s[k]=0;
				i = 0;
				continue;
			}
			i++; 
		}
		        s[i] = 0;
				v = atoi(s);
				
				insert(u,v);
				for(k = 0; k < i; k++)
					s[k]=0;
				i = 0;
//
           
        exchange(10);
		
		}


	//����֮��ĺϲ�
	for(i = 0;i <30; i++)
		for(j = i+1;j <30; j++)
		{
			
			if(g->v[i].exp>=0&&g->v[i].exp == g->v[j].exp)
			{
				if((g->v[i].position==g->v[j].position+mul(2,g->v[i].exp))&&(g->v[j].position%mul(2,g->v[i].exp+1) == 0))         //�ǻ��
				{
					g->v[i].exp = g->v[i].exp+1;
					g->v[i].position = g->v[j].position;
					g->v[j].exp = -1;
					break;
				}
				if((g->v[i].position==g->v[j].position-mul(2,g->v[i].exp))&&(g->v[j].position%mul(2,g->v[i].exp+1) == mul(2,g->v[i].exp)))//�ǻ��
				{
					g->v[i].exp = g->v[i].exp+1;
					g->v[j].exp = -1;
					break; 0;
				}

			}
		}
		


	

    exchange(10);




	flag = 0;
	for(i = 0;i < 30;i++)
	{
		flag = 0;
		for(j = 0;j <30; j++)
			if(g->v[j].exp ==i &&flag == 0)
			{    flag = 1;
				printf("%d %d",g->v[j].exp,g->v[j].position);
			}
			else if(g->v[j].exp ==i &&flag == 1)
			{
				printf(" %d",g->v[j].position);
			}
			else if(j == 29&&flag == 1)
			{
				printf("\n");
			}
	}
return 0;
}

int insert(int u, int v)
{
	int k = 0;
	flag = 0;
	for(int i = 0;i < 30; i++)
	{
		if(i>=1)
		{
		if(g->v[i-1].exp==u&&g->v[i].exp!=u)
			flag = 1;
		}
		
		if(g->v[i].exp == u)
		{
			
			     
				if((g->v[i].position==v+mul(2,u))&&(v%mul(2,u+1) == 0))         //�ǻ��
				{
					g->v[i].exp = u+1;
					g->v[i].position = v;
					return 0;
				}
				if((g->v[i].position==v-mul(2,u))&&(v%mul(2,u+1) == mul(2,u)))//�ǻ��
				{
					g->v[i].exp = u+1;
					
					return 0;
				}
				if(v < g->v[i].position )
				{
					while(g->v[k].exp>=0)
						{k++;}   //K�����һ��Ԫ��+1
				for(int j = k;j > i;j--)
					{
						g->v[j].exp = g->v[j-1].exp;
					    g->v[j].position = g->v[j-1].position;
					    
					}   
					    g->v[i].exp = u;
					    g->v[i].position = v;
					    
						return 0;
				}
		}
		if(g->v[i].exp > u)
		{     
		        while(g->v[k].exp>=0)
						{k++;}   //K�����һ��Ԫ��+1
				
				for(int j = k;j > i;j--)
					{
						g->v[j].exp = g->v[j-1].exp;
					    g->v[j].position = g->v[j-1].position;
						
					    
					}
					    g->v[i].exp = u;
					    g->v[i].position = v;
					    
						return 0;	
		}
		if(g->v[i].exp == -1&&flag == 1)
		{
			g->v[i].exp = u;
			g->v[i].position = v;
			return 0;
		}
	}

}
int mul(int i,int j)
{
	int temp;
	temp = i;
	for(int k = 1;k<j;k++)
		temp = temp*i;
	return temp;
}
void exchange(int j)
{int temp1,temp2;
temp1 = 0;
temp2 = 0;
for(int k = 0;k < j;k++)
	for(int i = k;i < j;i++)
	{
		if(g->v[i].exp > g->v[i+1].exp&&g->v[i].exp!=-1&&g->v[i+1].exp!=-1)
		{
			temp1 = g->v[i].exp;
			temp2 = g->v[i].position;
			g->v[i].exp = g->v[i+1].exp;
			g->v[i].position = g->v[i+1].position;
			g->v[i+1].exp = temp1;
			g->v[i+1].position = temp2;
		} 
	}//��exp����
	for(int k = 0;k < j;k++)
	for(int i = k;i < j;i++)
	{
		if(g->v[k].position > g->v[i].position&&g->v[k].exp==g->v[i].exp&&g->v[k].exp!=-1)
		{
			temp2 = g->v[i].position;
			
			g->v[i].position = g->v[k].position;
			
			g->v[k].position = temp2;
		} 
	}
}