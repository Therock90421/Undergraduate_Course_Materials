#include<stdio.h>

int func(char *s1,char *s2)      //s1�ǲ���s2���Ӵ�
{
	char *p=s2;
	for(;*s1;s1++)
	{
		for(;*p;p++)
		{
			if(*p==*s1)
			{
				break;
			}
		}
		if(*p=='\0')
		{
			return 0;
		}
		p++;
	}
	return 1;
}
int main(void)
{
	char s[1000] = {0};
	char c;
	char a[1000] = {0};
	char b[1000] = {0};
	char cur[1000] = {0};
	int i,j,k,ns,na,pos,length;
	ns = 0;i = 0;na = 0; pos = 0;
    length = 0;
	while(scanf("%c",&c)!=EOF)
	{   
		if(c == '\n')
		{
			for(i = 0;i < ns;i++)
			{   

               for(k=0;k<1000;k++)
				   a[k] = 0;            //��a��ʼ��


			
				for(na = i;na < ns; na++)
				{
					for(j = 0;j < na-i+1;j++)
					{
						a[j] = s[i+j];            //a[]Ϊs��һ���Ӵ� s[i]��s[na]
					}
					
					for(k=0;k<1000;k++)
				   b[k] = 0;            //��b��ʼ��
					
					for(j = 0;j < ns ; j++)
				{
					b[j] = s[na+j+1];              //b[]Ϊs��s[na+1]��ʼ���Ӵ�
				}
					if(func(a,b))                    //���a��b���Ӵ�����a���ظ�������
					{
						if(length < na-i+1)
						{
							length = na-i+1;
							pos = i;
							for(j = 0;j <length;j++)
							{
						    	cur[j] = a[j];           //curΪ��ǰ��ظ�������
							}
						}
					}
				}
			}
			if(length == 0)
		    printf("-1");
			else
			{printf("%s",cur);

	         printf(" %d\n",pos);
			}
			continue;
		}
		s[ns] = c;
		ns++;
	}

	
	return 0;
}