#include<stdio.h>
#include<stdlib.h>



int main()
{
	int left[1000];
    int right[1000];
	char read[1000];
	int T[1000];
	
	int i,j,u,v,length;

	i = 0;
	j = 0;
	length = 0;
	while(scanf("%c",&read[i])!= EOF &&read[1000]!='\n' )
	{
		if(read[i]==','||read[i]==';')
		{
			if(read[i]==';')
				break;
			read[i] = 0;
			left[j++] = atoi(read);
			i = 0;
			continue;
		}
		else i++;
	}
	         read[i] = 0;
			 left[j++] = atoi(read);
			 length = j;
	i = 0;
	j = 0;
	while(scanf("%c",&read[i])!= EOF &&read[1000]!='\n' )
	{
		if(read[i]==','||read[i]==';')
		{
			if(read[i]==';')
				break;
			read[i] = 0;
			right[j++] = atoi(read);
			i = 0;
			continue;
		}
		else i++;
	}
	         read[i] = 0;
			 right[j++] = atoi(read);
    i = 0;
	j = 0;

	while(scanf("%c",&read[i])!= EOF &&read[1000]!='\n' )
	{
		if(read[i]==';')
		{		
			read[i] = 0;
			u = atoi(read);
			i = 0;
			break;
		}
		else i++;
	}
    i = 0;
	j = 0;

	while(scanf("%c",&read[i])!= EOF &&read[1000]!='\n' )
	{	
		 i++;
	}
		read[i] = 0;
		v = atoi(read);
		j = 0;
		i = 0;

		 
    for(i=0; i<length; i++)
        T[i] = 0;
    for(i=1; i<length; i++){
        if(left[i]!=0)
            T[left[i]] = i;
        if(right[i]!=0)
            T[right[i]] = i;
    }

	while(u)
	{
		u = T[u];
		if(u == v){
			printf("1");
		return 0;
		}
	}
	printf("0");
	return 0;
}