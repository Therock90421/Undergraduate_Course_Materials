#include<stdio.h>
#include<stdlib.h>

#define MAX_VERTEX_NUM 30
typedef int ElemType;
typedef struct node {
    int vindex; 	//�ڽӵ���ͷ��������е�λ��(�±�)
    struct node *next; //ָ����һ�������
} NodeLink; // ��������Ͷ���
typedef struct {
    // ͼ�Ķ�����������
    int vexnum; 
    struct {
        ElemType vertex;
        NodeLink *first;// ָ���һ�������
    }v[MAX_VERTEX_NUM];
}AGraph;
int flag;
int sign;
void ListGraph(AGraph *g);
int visit[100]={0};
int DFS(AGraph *g,int u,int v);
int main()
{
	int number;
	
	char s[10]={0};
	int L[100]={0};
	int fst[100]={0};
	int lst[100]={0};
	AGraph *g;
	NodeLink *p,*q,*r;
	int u,v,i,j,k;
	i = 0;
	u = 0;
	v = 0;
	scanf("%c",&s[i]);
	number = atoi(s);
	scanf("%c",&s[0]);
	g = (AGraph *)malloc(sizeof(AGraph));
	g->vexnum = number;
	for(i = 1;i<=number;i++)
	{
		g->v[i].vertex = i;
		g->v[i].first = NULL;
	}
	
	i = 0;
	j = 0;
	while(scanf("%c",&s[i])!=EOF&&s[i]!='\n')
	{
		if(s[i]==' ')
		{
			s[i] = 0;
		    
		    u = atoi(s);
		
		    L[j] = u;
		    j++;
			i = 0;
		}
		else {
			i++;}
	}
	s[i] = 0;
    u = atoi(s);
	L[j] = u;
	j = 0;
	i = 0;
	while(scanf("%c",&s[i])!=EOF&&s[i]!='\n')
	{
		if(s[i]==' ')
		{
			s[i] = 0;
		    
		    u = atoi(s);
		
		    fst[j] = u;
		    j++;
			i = 0;
		}
		else i++;
	}
	s[i] = 0;
    u = atoi(s);
	fst[j] = u;
	j = 0;
	i = 0;
	while(scanf("%c",&s[i])!=EOF&&s[i]!='\n')
	{
		if(s[i]==' ')
		{
			s[i] = 0;
		    
		    u = atoi(s);
		
		    lst[j] = u;
		    j++;
			i = 0;
			
		}
		else i++;
	}
	s[i] = 0;
    u = atoi(s);
	lst[j] = u;
	j = 0;
	i = 0;
	k = 0;

	for(i = 1;i <= number;i++)
	{
		if(fst[i]<=lst[i])
			for(j = fst[i];j<=lst[i];j++)
			{
		sign = 0;
		r = (NodeLink *)malloc(sizeof(NodeLink));
		r->vindex = L[j];
		for(k = fst[i];k<j;k++)
		{
			if(L[k]==L[j])
				sign = 1;
			if(L[j]==0)
				sign = 1;
		}
		if(sign == 0)
		{
		if(g->v[i].first==NULL)
		{
			g->v[i].first=r;
			r->next = NULL;
			
		}
		else
		{
			p = g->v[i].first;
			q = p->next;
			while(q!=NULL&&r->vindex > q->vindex)
			{
			
				p = q;
				q = q->next;
			}
			
			p->next = r;
			r->next = q;
			
		}
			}

			}
	}
	
	for(i = 1;i <= number;i++)
		for(j = i+1;j <= number; j++)
		{
			
                flag = 0;
				DFS(g,i,j);
				if(flag == 1)
				{
					flag = 0;
					DFS(g,j,i);
					if(flag == 1)
					{
					printf("yes");
					return 0;
					}
				
			}
		}
	printf("no");
	return 0;


}


void ListGraph(AGraph *g) {
int i; NodeLink *p;
for(i=1;i<=g->vexnum;i++){
    printf("%d:%d--->",i,g->v[i].vertex);
    p=g->v[i].first;
    while(p) {
        printf("%3d",p->vindex);
        p=p->next;}
    printf("\n");
    }
}

int DFS(AGraph *g,int u,int v)
{
	NodeLink *p;
	visit[u]=1;
	if(g->v[u].first==NULL);
	else
	{
		p = g->v[u].first;
		while(p!=NULL)
		{
		if(p->vindex==v )
		{
			flag = 1;
			return 0;
		}
		else 
		{
			//visit[p->vindex]=1;
			if(visit[p->vindex]==0)
			DFS(g,p->vindex,v);
		}
		p = p->next;
		}
	}
}	
