#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main()
{
	int L[100][100]={0};
	int K[1000] = {0};
	int M[1000] = {0};
	char s[1000]={0};
	int i,j,k;
	int u,v;
	int number,edge;
	 
	number = 0;
	edge = 0;
	i = 0;
	j = 0;
	u = 0;
	v = 0;
   
	while(scanf("%c",&s[i])!=EOF)
	{
		if(s[i]==','||s[i]==' ')
			break;
		i++;
	}
	
	s[i] = 0;
	number = atoi(s);
	
	i = 0;
	while(scanf("%c",&s[i])!=EOF&&s[i]!='\n')
	{
		
		i++;
	}
	s[i] = 0;
	edge = atoi(s);
	i = 0;
	while(scanf("%c",&s[i])!=EOF&&s[i]!='\n')
	{
		if(s[i]=='-')
		{
			s[i] = 0;
			u = atoi(s);
			i = 0;
			continue;
		}
		if(s[i]==',')
		{
			s[i]=0;
			v = atoi(s);
			i = 0;
			L[u][v] = 1;
			
			K[u]++;
			M[v]++;
			continue;
		}
		i++;
	}
	        s[i]=0;
			v = atoi(s);
			i = 0;
			L[u][v] = 1;
			K[u]++;
			M[v]++;
	for(i = 0;i <= number;i++)
	{
		j = number;
		if(K[i]==0&&M[i]==0){}
		else if(K[i]==0)
			printf("%d\n",i);
		else printf("%d ",i);
		while(K[i])
		{
            while(L[i][j]==0)
			j--;
			
			if(K[i]>1) printf("%d,",j);
			else printf("%d\n",j);
			K[i]--;
			j--;
		}
	}

	return 0;
}