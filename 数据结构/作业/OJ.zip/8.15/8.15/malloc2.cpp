#include<stdio.h>
#include<stdlib.h>




int main()
{
	int L[100]={0};
	int K[100]={0};
	int c,i,j,k,u,v,lowbound,highbound,cellsize,length,flag;
	char s[10];
	i = 0;
	j = 0;
	k = 0;
	c = 0;
	u = 0;
	v = 0;
	lowbound = 0;highbound = 0;cellsize = 0;length = 0;
	while(scanf("%c",&s[i])!=EOF&&s[i]!=' ')
	{
		i++;
	}
	s[i] = 0;
	lowbound = atoi(s);        //lowbound����
	for(j = 0;j < i; j++)
	    s[j] = 0;
	i = 0;

	while(scanf("%c",&s[i])!=EOF&&s[i]!=' ')
	{
		i++;
	}
	s[i] = 0;
	highbound = atoi(s);       //highbound����
	for(j = 0;j < i; j++)
	    s[j] = 0;
	i = 0;

	while(scanf("%c",&s[i])!=EOF&&s[i]!='\n')
	{
		i++;
	}
	s[i] = 0;
	cellsize = atoi(s);          //cellsize����
	for(j = 0;j < i; j++)
	    s[j] = 0;
	i = 0;

	length = (highbound-lowbound)/cellsize;
	j = 0;
	while(scanf("%c",&s[i])!=EOF&&s[i]!='\n')
	{
		if(s[i] == ' ')
		{
			s[i] = 0;
			L[j] = atoi(s);
			for(k = 0;k < i; k++)
	             s[k] = 0;
			i = 0;
			j++;
			continue;
		}
		i++;
	}
	s[i] = 0;
	L[length-1] = atoi(s);
	for(k = 0;k < i; k++)
	    s[k] = 0;
	i = 0;

	for(i = 0; i< length; i++)
	      K[i] = cellsize;
	for(i = length-1;i >= 0; i--)
	{
		if(L[i]==0&&L[i-1]==0)
		{
			L[i] = 2;    //���ϲ�
			K[i-1] = K[i-1]+K[i];
		}
	}

	flag = 0;

	for(i = 0; i<length; i++)
	{
		if(L[i]==0)
			{
				printf("0 %d %d\n",2*i+lowbound,K[i]);
				flag = 1;
		}
	}
	if(flag == 0)
		printf("0 0 0");
    return 0;
	
}