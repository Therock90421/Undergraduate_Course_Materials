/*#include<stdio.h>
///#define equal 0
//#define large 2
//#define small 1
int main(){
	int i,k,na,nb,n;
	char va[1000],vb[1000];
	na=0;
	nb=0;
	n=0;
	while(scanf("%c",&va[na])!=EOF){
		if(va[na]==';')
			break;
		if(va[na]!=',')
			na++;
		}
	while(scanf("%c",&vb[nb])!=EOF){
		if(vb[nb]!=',')
			nb++;}
	n=(na>nb)?nb:na;
	i=0;
	while((va[i]==vb[i])&&i<n)
		i++;
	if(i==n && na==nb)
		printf("0");
	if((va[i]>vb[i])||i==nb)
		printf("2");
	if(vb[i]<va[i]||i==na)
		printf("1");
	return 0;}*/
#include<stdio.h>

int min(int x, int y)
{
    if(x < y)
        return x;
    else return y;
}

int main()
{
    int k, n, na, nb;
    char va[1000], vb[1000];
    na = 0;
    while(scanf("%c", &va[na]) != EOF)
    {
        if(va[na] == ';')
            break;
        if(va[na] != ',')
            na++;
    }
    nb = 0;
    while(scanf("%c", &vb[nb]) != EOF)
    {
        if(vb[nb] != ',')
            nb++;
    }
	nb--;
    k = 0;
    n = min(na, nb);
    while(k < n && (va[k] == vb[k]))
        k++;
    if(na==nb){
	   if(k == n)
	       printf("0");
	   else {
	   if(va[k]>vb[k]) printf("2");
	   if(va[k]<vb[k]) printf("1");}   }
	else {
    if(k == na || va[k] < vb[k])
        printf("1");
    if(k == nb || va[k] > vb[k])
		printf("2");}

    return 0;
}