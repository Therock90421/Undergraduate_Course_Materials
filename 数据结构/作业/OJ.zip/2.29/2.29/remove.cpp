#include<stdio.h>

int main()
{
    int na, nb, nc,i,j,k,left;
    char va[1000], vb[1000], vc[1000],v[1000];
    na = 0;
    while(scanf("%c", &va[na]) != EOF)
    {
        if(va[na] == ';')
            break;
        if(va[na] != ',')
            na++;
    }
    nb = 0;
    while(scanf("%c", &vb[nb]) != EOF)
    {
        if(vb[nb] == ';')
            break;
        if(vb[nb] != ',')
            nb++;
    }
    nc = 0;
    while(scanf("%c", &vc[nc]) != EOF)
    {
        if(vc[nc] != ',')
            nc++;
    }
	nc--;
	
	i = 0; j = 0; k = 0; 
	left = 0;
    while(i< na && j < nb && k < nc)
    {
        if(vb[j] < vc[k])
            j++;
        else if(vb[j] > vc[k])
            k++;
        else                  //vb[j]==vc[k]
        {
            while(i < na && va[i] < vb[j])
            {
                v[left] = va[i];
                left++; i++;
            }
            while(i < na && va[i] == vb[j])
                i++;                                   //��ʱ
            j++; k++;
        }
    }                                                  //��B,C���ظ���Ԫ�ش�A��ɾ�����������С�������ظ�Ԫ�صĲ��ַŵ�v��ǰ�沿��
	while(i<na){
		v[left]=va[i];
		left++;
		i++;}
	i = 0;
	for(i = 0;i<left-1;i++)
		printf("%c,",v[i]);
	printf("%c",v[i]);
	return 0;}