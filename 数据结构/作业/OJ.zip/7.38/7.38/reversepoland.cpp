#include<stdio.h>
#include<stdlib.h>

#define MAX_VERTEX_NUM 30
typedef char ElemType;
typedef struct node {
    int vindex; 	//�ڽӵ���ͷ��������е�λ��(�±�)
    struct node *next; //ָ����һ�������
} NodeLink; // ��������Ͷ���
typedef struct {
    // ͼ�Ķ�����������
    int vexnum; 
    struct {
        ElemType vertex;
        NodeLink *first;// ָ���һ�������
    }v[MAX_VERTEX_NUM];
}AGraph;
int flag;
void ListGraph(AGraph *g);
int visit[100]={0};
int DFS(AGraph *g,int u,int v);
int nowlength;
int show(AGraph *g, int number,int i);
int main()
{
	int number;
	int length;
	
	char s[10]={0};
	AGraph *g;
	NodeLink *p,*q,*r,*t;
	char elem;
	int i,h,k;
    int u,v;
	i = 0;	
	h = 0;
	k = 0;
	u = 0;
	v = 0;
	scanf("%c",&s[i]);
	number = atoi(s);
	scanf("%c",&s[0]);
	
	g = (AGraph *)malloc(sizeof(AGraph));
	g->vexnum = number;
	for(i = 0;i<number;i++)
	{
		
		g->v[i].first = NULL;
	}
	
	i = 0;
	do{
		scanf("%c",&s[0]);
		elem = s[0];
		
		if(elem == '+'||elem == '-'||elem == '*'||elem == '/')
		{
		g->v[i].vertex = elem;
		scanf("%c",&s[0]);
		scanf("%c",&s[0]);
		u = atoi(s);
		scanf("%c",&s[0]);   
		scanf("%c",&s[0]);
		v = atoi(s);
		 
		
		r = (NodeLink *)malloc(sizeof(NodeLink));
		r->vindex = u;
		
			g->v[i].first=r;
			r->next = NULL;
		t = (NodeLink *)malloc(sizeof(NodeLink));
		t->vindex = v;
		
			p = g->v[i].first;
			p->next = t;
			
			t->next = NULL;
		    i++;
		}
		else 
		{
			g->v[i].vertex = elem;
			i++;
		}
	}while(scanf("%c",&s[0])!=EOF);

	flag = 0;
	nowlength = 0;

	
	show(g,number,0);

	return 0;
	


}


void ListGraph(AGraph *g) {
int i; NodeLink *p;
for(i=0;i<g->vexnum;i++){
    printf("%d:%c--->",i,g->v[i].vertex);
    p=g->v[i].first;
    while(p) {
        printf("%3d",p->vindex);
        p=p->next;}
    printf("\n");
    }
}
int show(AGraph *g, int number,int i)
{
	int k = 0;
	int h = 0;
	if(number>=i)
	if(g->v[i].vertex == '+'||g->v[i].vertex == '-'||g->v[i].vertex == '*'||g->v[i].vertex == '/')
	{
		NodeLink *p,*t;
		p = g->v[i].first;
		k = p->vindex;
		//if(g->v[k].vertex == '+'||g->v[k].vertex == '-'||g->v[k].vertex == '*'||g->v[k].vertex == '/')
		
		t = p->next;
		h = t->vindex;
		show(g,number,h);
		show(g,number,k);
		printf("%c",g->v[i].vertex);
	}
	else
		{
			printf("%c",g->v[i].vertex);
			return 0;
	}
}

int DFS(AGraph *g,int u,int v)
{
	NodeLink *p;
	visit[u]=1;
	if(g->v[u].first==NULL);
	else
	{
		nowlength++;
		p = g->v[u].first;
		while(p!=NULL)
		{
		if(p->vindex==v )
		{
			flag = 1;
			
			return 0;
			
		}
		else 
		{
			if(visit[p->vindex]==0)
			{
				
			DFS(g,p->vindex,v);
			if(flag==0)
			{
			nowlength--;
			}
			
			}
		}
		p = p->next;
		
		
		}
	}
}	


