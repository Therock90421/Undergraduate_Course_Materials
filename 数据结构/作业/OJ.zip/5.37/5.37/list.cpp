#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef enum{lable, number} ElemType;
typedef struct{
    ElemType Type;
    union{
        char lable;
        int number;
    };
} Elem;
typedef enum {ATOM, LIST} ElemTag;
typedef struct GLNode{
    ElemTag Tag;
    union{
        Elem atom;
        struct {struct GLNode *hp, *tp;}ptr;
    };
} *Glist;

int CreateGlist(Glist L, char S[100]);         //�ɶ��봴��һ�������
int Delete_GL(Glist *L, Elem );               //�ӹ������ɾ��Ԫ��
int ShowGlist(Glist L, char S[100]);          //��ӡ�����
int Serve(char sub[100], char hsub[100]);     //��һ��ȥ���������ŵĹ������ɱ�ͷ�ͱ�β
int StrSubStr(char sub[100], char S[100], int a, int l);   //��ȡ��a��ʼ������Ϊl���ַ�����ֵ��sub
int IsAtom(char *S);                          //�ж�
int CreateGlist(Glist L, char S[100])
{
    
    Glist p, q;
    char sub[100];
    char hsub[100];
    if(!strcmp(S, "()"))           //���Ϊ����
        L = NULL;
    else{
        
        if(IsAtom(S)){
            L->Tag = ATOM;
            if(S[0]>='A'&&S[0]<='z'){
                L->atom.Type = lable;
                L->atom.lable = S[0];
            }
            else{
                L->atom.Type = number;
                L->atom.number = atoi(S);
            }
        }
        else{
            L->Tag = LIST;
            p = L;
            StrSubStr(sub, S, 2, strlen(S)-2);
            do{
                Serve(sub, hsub);
                p->ptr.hp = (Glist)malloc(sizeof(struct GLNode));
                CreateGlist(p->ptr.hp, hsub);
                q = p;
                if(strlen(sub)){
                    p = (Glist)malloc(sizeof(struct GLNode));
                    p->Tag = LIST;
                    q->ptr.tp = p;
                }
            }while(strlen(sub));
            q->ptr.tp = NULL;
        }
    }

    return 1;
}

int Delete_GL(Glist *L, Elem x)
{
    int Eq(Elem, Elem);
    Glist *head, p;
    if(*L){
        head = &((*L)->ptr.hp);
        if((*head)->Tag==ATOM && Eq((*head)->atom, x)){
            free(*head);
            p = *L;
            *L = (*L)->ptr.tp;
            free(p);
            Delete_GL(L, x);
        }
        else if((*head)->Tag==LIST){
            Delete_GL(head, x);
            Delete_GL(&((*L)->ptr.tp), x);
        }
        else
            Delete_GL(&(*L)->ptr.tp,x);
    }
    return 1;
}
int ShowGlist(Glist L, char S[100])
{
    void myitoa (int n, char s[]);
    char t[100];
    static int i = 0;
    int j,k = 0;
    Glist p;
    if(!L){
        S[i++] = '(';
        S[i++] = ')';
        S[i] = 0;
        return 1;
    }
    if(L->Tag==ATOM)
        if(L->atom.Type==lable)
            S[i++] = L->atom.lable;
        else{
            myitoa(L->atom.number, t);
			k = strlen(t);
            for(j=k-1; j>=0; j--)
                S[i++] = t[j];
        }
    else{
        p = L;
        S[i++] = '(';
        do{
            ShowGlist(p->ptr.hp, S);
            if(p){
                if(p->ptr.tp)
                    S[i++] = ',';
                p = p->ptr.tp;
            }
        }while(p);
        S[i++] = ')';
        S[i] = 0;
    }
    return 1;
}

int Serve(char sub[100], char hsub[100])
{
    int i, k, n;
    i = 0;
    k = 0;
    n = strlen(sub);
    do{
        if(sub[i]=='(')
            k++;
        else if(sub[i]==')')
            k--;
        i++;
    }while(i<n && (sub[i]!=','||k!=0));
    if(i<n){
        StrSubStr(hsub, sub, 1, i);
        StrSubStr(sub, sub, i+2, n-i-1);
    }
    else{
        strcpy(hsub, sub);
        sub[0] = 0;
    }
    return 1;
}

int StrSubStr(char sub[100], char S[100], int a, int l)
{
    char temp[100];
    char *ptemp;
    strcpy(temp, S);
    temp[a+l-1] = 0;
    ptemp = temp + a - 1;
    strcpy(sub, ptemp);
    return 1;
}

int IsAtom(char *S)
{
    if(strlen(S)==0)
        return 0;
    int i;
    for(i=0; S[i]; i++)
        if(S[i]=='('||S[i]==')'||S[i]==',')
            return 0;
    return 1;
}

void myitoa (int n,char s[])              //������ת��Ϊ�ַ���
{
    void reverse(char *s);
    int i,j,sign;
    if((sign=n)<0)
    n=-n;
    i=0;
do{
       s[i++]=n%10+'0';
}
while ((n/=10)>0);
if(sign<0)
s[i++]='-';
s[i]='\0';

}


int Eq(Elem a, Elem b)
{
    if(a.Type==number)
        if(b.Type==number && a.number==b.number)
            return 1;

    if(a.Type==lable)
        if(b.Type==lable && a.lable==b.lable)
            return 1;
    return 0;
}





int main()
{
    int i;
    i = 0;
    Elem x;
    char S[100];
    char item[1000];
	
    while(scanf("%c", &item[i])!=EOF && item[i]!='\n'){
        if(item[i] == ';'){
            if(item[i-1]>='A'&&item[i-1]<='z'){
                x.Type = lable;
                x.lable = item[i-1];
            break;
            }
            item[i] = 0;
            x.Type = number;
            x.number = atoi(item);
            i = 0;
            break;
        }
        i++;
    }
    i = 0;
    while(scanf("%c", &S[i])!=EOF && S[i]!='\n') i++;
    S[i] = 0;

    Glist L;
    L = (Glist)malloc(sizeof(struct GLNode));


    



	CreateGlist(L,S);
    Delete_GL(&L, x);
    ShowGlist(L, S);
    
    printf("%s\n", S);

}



