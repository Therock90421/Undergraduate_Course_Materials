#include<stdio.h>
#include<stdlib.h>


int main(){
	int a,b,k,i,flag,m,lenth,number;
	int *s;  //����
	int element[1000]={0};
	char put;
	char c[1000] = {0};
	
	a = 0;
	b = 0;
	lenth = 0;
	k = 0;
	m = 0;
	flag = 0;
	number = 0;
	while(scanf("%c",&put)!=EOF){
		if(put == ';'&&flag<2){
	    if(flag == 0)
			{
		     a = atoi(c);                  //a�Ǳ�Ԫ����
		     for(i = 0; i < k;i++)
			     c[i] = 0;
		     k = 0;
			 flag++;
			 		
             continue;
		    }
		else
		{
		     b = atoi(c);                 //b��ÿһά�ĳ���
		     for(i = 0; i < k;i++)
			     c[i] = 0;
		     k = 0;
			 flag++;

			 lenth = b;
		for(i = 1; i < a;i++)
			     lenth = lenth*b;	  		

        s = (int *)malloc(sizeof(int)*(lenth));
		
		for(i = 0; i < lenth;i++)
			     *(s+i) = 0;
		
		continue;
		}
		}

		if((put == ';'&&flag==2)||(put ==','))
		{  
			number=atoi(c);
			s[m]=number;
			m++;
			
			
			
			for(i = 0; i < k;i++)
			     c[i] = 0;
		     k = 0;
			 continue;
		}
		if(put == '\n')
		{
			*(s+m)=atoi(c);
			m++;
			for(i = 0; i < k;i++)
			     c[i] = 0;
		     k = 0;
			 continue;
		}
		
		if(put == '['||put == ']')
			continue;

		c[k] = put;
		k++;
		
	}//��ɶ���
	k = 0;

	for(i = 0;i<lenth;i++)
		if(s[i]!=0)
		{
			element[k++]=s[i];
			s[i] = 1;
		}
    printf("[");
	if(!k)
		printf("];[");
	else 
		{
			for(i = 0; i < k-1; i++)
		printf("%d,",element[i]);
	printf("%d];[",element[k-1]);
	}
    for(i = 0;i < a-1; i++)
	{
		printf("[");
	    for(m = 0; m < b-1; m++)
		   printf("%d,",s[i*b+m]);
	    printf("%d];",s[i*b+b-1]);
	}
	    printf("[");
	    for(m = 0; m < b-1; m++)
		   printf("%d,",s[i*b+m]);
	    printf("%d]]",s[i*b+b-1]);

    return 0;


}