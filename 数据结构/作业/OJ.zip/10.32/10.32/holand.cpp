#include<stdio.h>

int main()
{
	int r,w,b,color;
	char c;
	r = 0;
	w = 0;
	b = 0;
	while((color = getchar())!=EOF&&color!='\n')
	{
		if(color == 48)
			r++;
		if(color == 49)
			w++;
		if(color == 50)
		    b++;

	}
	while(r>0)
	{
		printf("0,");
		r--;
	}
	while(w>0)
	{
		printf("1,");
		w--;
    }
	while(b > 1)
	{
		printf("2,");
		b--;
	}
	printf("2");
	return 0;
}