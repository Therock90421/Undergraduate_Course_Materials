#include<stdio.h>

int main(){
	int n;
	char c;
	n = 0;
	while((c=getchar())!=EOF){
		if(c == '(')
			n++;
		if(c == ')')
			n--;}
	if(n==0)
		printf("%d",n+1);
	else{
		n=0;
		printf("%d",n);
	}
	return 0;}